import java.util.Date;

public class ArrayOrdenado {
    public static void main(String[] args) {
        compararArreglos();
    }
    public static void compararArreglos() {
        long tiempoInicio = new Date().getTime();
        OrdArray ordArray = new OrdArray(10000);
        OrdArray ordArray1 = new OrdArray(10000);
        ordArray.insert();
        ordArray1.insert();
        int ocurrencias = ordArray.getOccurrences(ordArray1);
        System.out.println("N° de ocurrencias: " + ocurrencias);
        long tiempoFinal = new Date().getTime();
        long tiempoEjecucion = tiempoFinal - tiempoInicio;
        System.out.println("Tiempo de ejecución: " +tiempoEjecucion+ " milisegundos");
    }
}
