public class Executable {
    public static void main(String[] args) {
        Permiso permiso = new Permiso();
        permiso.cargarPermisos();
        permiso.quickSort();
    }
}
