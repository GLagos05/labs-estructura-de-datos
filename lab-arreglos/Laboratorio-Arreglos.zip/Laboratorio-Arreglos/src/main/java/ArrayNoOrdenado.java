import java.util.Date;

public class ArrayNoOrdenado {
    public static void main(String[] args) {
        compararArreglos();
    }
    public static void compararArreglos(){
        long tiempoInicio = new Date().getTime();
        HighArray highArray = new HighArray(10000);
        HighArray highArray1 = new HighArray(10000);
        highArray.insert();
        highArray1.insert();
        int ocurrencias = highArray.getOccurrences(highArray1);
        System.out.println("N° de ocurrencias: "+ocurrencias);
        long tiempoFinal = new Date().getTime();
        long tiempoEjecucion = tiempoFinal-tiempoInicio;
        System.out.println("Tiempo de ejecución: " +(tiempoEjecucion)+ " milisegundos");
    }

}
